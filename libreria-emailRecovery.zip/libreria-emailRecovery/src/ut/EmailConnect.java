package ut;

import java.util.Properties;
import java.util.Random;
import javax.mail.*;
import javax.mail.internet.*;

public final class EmailConnect {
    
    
    private static final Properties DEFAULT_PROPERTIES = new Properties();

    static {
     
        DEFAULT_PROPERTIES.put("mail.smtp.host", "smtp.gmail.com");
        DEFAULT_PROPERTIES.put("mail.smtp.port", "587");
        DEFAULT_PROPERTIES.put("mail.smtp.auth", "true");
        DEFAULT_PROPERTIES.put("mail.smtp.starttls.enable", "true");
        DEFAULT_PROPERTIES.put("mail.smtp.starttls.required", "true");
        DEFAULT_PROPERTIES.put("mail.smtp.ssl.protocols", "TLSv1.2");
        DEFAULT_PROPERTIES.put("mail.smtp.ssl.trust", "smtp.gmail.com");
    }

    // Constructor privado para evitar instanciación
    private EmailConnect() {
    }

    /**
     * Envía un email usando la configuración por defecto (Gmail)
     *
     * @param fromEmail Email del remitente
     * @param password Contraseña del remitente
     * @param toEmail Email del destinatario
     * @param subject Asunto del correo
     * @param htmlContent Contenido HTML del correo
     * @throws MessagingException Si ocurre un error al enviar el correo
     */
    public static void sendEmail(String emailEmpresa,String clave,String nombre, String contrasena, String emailTo) throws MessagingException {
        
           String asunto = "RECUPERACION DE CONTRASEÑA";
            String contenidoHtml = "<h1>Hola, " + nombre + ".</h1>"
                    + "<p>Se ha solicitado la recuperación de su contraseña.</p>"
                    + "<p><strong>El codigo de recuperacion es:</strong> " + contrasena + "</p>"
                    + "<p>Ingrese el codigo para restablecer su contraseña para ingresar al sistema.</p>";
        Properties props = (Properties) DEFAULT_PROPERTIES.clone();
        props.setProperty("mail.smtp.user", emailEmpresa);

        Session session = Session.getDefaultInstance(props);
        MimeMessage message = createMessage(session, emailEmpresa,emailTo, asunto, contenidoHtml);
        sendMessage(session, message,emailEmpresa, clave);
    }

    private static MimeMessage createMessage(Session session, String fromEmail,
            String toEmail, String subject,
            String htmlContent) throws MessagingException {
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(fromEmail));
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
        message.setSubject(subject);
        message.setText(htmlContent, "ISO-8859-1", "html");
        return message;
    }

    private static void sendMessage(Session session, MimeMessage message,
            String fromEmail, String password) throws MessagingException {
        Transport transport = session.getTransport("smtp");
        try {
            transport.connect(fromEmail, password);
            transport.sendMessage(message, message.getRecipients(Message.RecipientType.TO));
        } finally {
            transport.close();
        }
    }
    public static String generarCodigoRandom(){
        String codigo="";
        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        
        Random random = new Random();
        int longitud = 6; 
        
        for (int i = 0; i < longitud; i++) {
            int indice = random.nextInt(caracteres.length());
            codigo+=(caracteres.charAt(indice));
        }
        return codigo;
    }
    public static boolean verificarCodigo(String ingresado, String original) {
        return ingresado.trim().equalsIgnoreCase(original.trim());
    }
     public static void enviarCodigoRecuperacion(String emailOrigen, String passwordOrigen, String nombre, String codigo, String destino) throws MessagingException {
        ut.EmailConnect.sendEmail(emailOrigen, passwordOrigen, nombre, codigo, destino);
    }
}
